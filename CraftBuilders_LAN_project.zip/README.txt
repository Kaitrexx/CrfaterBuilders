CraftBuilders LAN - Android layihəsi (WebView + LAN server/axtarış)

YOL A - GitHub ilə (Android Studio lazım deyil):
 1. github.com-da yeni repo aç, bu qovluğun BÜTÜN məzmununu (gizli .github daxil) yüklə.
 2. Actions > "Build APK" > Run workflow. 3-6 dəqiqə sonra "CraftBuilders-LAN-apk" artefaktını endir (içində app-debug.apk).

YOL B - Android Studio: qovluğu aç > Build > Build APK(s).

Oyunu yeniləmək: app/src/main/assets/www/index.html faylını yeni oyun faylı ilə əvəz et.
Qeyd: tətbiq adı/paketi köhnədən fərqlidir (…craftbuilders.lan), köhnə tətbiq və onun dünyaları silinmir.
