plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.kaitrexgame.craftbuilders.lan"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.kaitrexgame.craftbuilders.lan"   // köhnə tətbiqdən FƏRQLİ: ikisi yanaşı qalır, köhnə dünyalar silinmir
        minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "1.201"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources.excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*") }
}
dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("org.java-websocket:Java-WebSocket:1.5.7")
    implementation("org.slf4j:slf4j-nop:2.0.13")
}
