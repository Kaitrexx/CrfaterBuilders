package com.kaitrexgame.craftbuilders.lan

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONObject
import java.net.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * HTML oyundakı [#LAN_BRIDGE] müqaviləsi (window.CBNative):
 *  JS -> native: scanStart/scanStop, hostStart(info)/hostUpdate(info)/hostStop, hostSend(cid,json)/hostKick(cid)
 *  native -> JS: CBLan.found({...}), CBLan.hostConn(cid), CBLan.hostData(cid,json), CBLan.hostClose(cid)
 * Server: WebSocket, port 8765 (hər mətn çərçivəsi olduğu kimi ötürülür). Elan/axtarış: UDP broadcast, port 8766.
 */
class LanBridge(private val ctx: Context, private val web: WebView) {
    companion object { const val PORT = 8765; const val DISC_PORT = 8766 }

    private val ui = Handler(Looper.getMainLooper())
    private val conns = ConcurrentHashMap<Int, WebSocket>()
    private val nextCid = AtomicInteger(1)
    @Volatile private var server: GameServer? = null
    @Volatile private var info = "{}"
    @Volatile private var announcing = false
    @Volatile private var scanning = false
    private var annThread: Thread? = null
    private var scanThread: Thread? = null
    private var scanSock: DatagramSocket? = null
    private var mlock: WifiManager.MulticastLock? = null

    private fun js(code: String) { ui.post { try { web.evaluateJavascript(code, null) } catch (_: Exception) {} } }
    private fun q(s: String) = JSONObject.quote(s)

    // ---------------- HOST ----------------
    private inner class GameServer : WebSocketServer(InetSocketAddress(PORT)) {
        override fun onOpen(c: WebSocket, h: ClientHandshake) { val id = nextCid.getAndIncrement(); c.setAttachment(id); conns[id] = c; js("window.CBLan&&CBLan.hostConn($id)") }
        override fun onMessage(c: WebSocket, m: String) { val id = c.getAttachment<Int>() ?: return; js("window.CBLan&&CBLan.hostData($id,${q(m)})") }
        override fun onClose(c: WebSocket, code: Int, reason: String?, remote: Boolean) { val id = c.getAttachment<Int>() ?: return; conns.remove(id); js("window.CBLan&&CBLan.hostClose($id)") }
        override fun onError(c: WebSocket?, e: Exception?) {}
        override fun onStart() { connectionLostTimeout = 30 }
    }

    @JavascriptInterface fun hostStart(infoJson: String) {
        hostStop(); info = infoJson
        try { val s = GameServer(); s.isReuseAddr = true; s.start(); server = s } catch (_: Exception) { return }
        startAnnounce()
    }
    @JavascriptInterface fun hostUpdate(infoJson: String) { info = infoJson }
    @JavascriptInterface fun hostSend(cid: Int, json: String) { val c = conns[cid] ?: return; try { if (c.isOpen) c.send(json) } catch (_: Exception) {} }
    @JavascriptInterface fun hostKick(cid: Int) { try { conns[cid]?.close() } catch (_: Exception) {} }
    @JavascriptInterface fun hostStop() {
        announcing = false; annThread?.interrupt(); annThread = null
        val s = server; server = null; conns.clear()
        try { s?.stop(200) } catch (_: Exception) {}
    }

    private fun broadcastAddrs(): List<InetAddress> {
        val r = ArrayList<InetAddress>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) {
                    val a = ia.address as? Inet4Address ?: continue
                    var b = ia.broadcast
                    if (b == null) {   // bəzi telefonlarda hotspot interfeysində broadcast boş gəlir: özümüz hesablayırıq
                        val p = ia.networkPrefixLength.toInt(); val ip = a.address
                        val v = ((ip[0].toInt() and 255) shl 24) or ((ip[1].toInt() and 255) shl 16) or ((ip[2].toInt() and 255) shl 8) or (ip[3].toInt() and 255)
                        val bv = v or (if (p == 0) 0 else (-1 shl (32 - p))).inv()
                        b = InetAddress.getByAddress(byteArrayOf((bv ushr 24).toByte(), (bv ushr 16).toByte(), (bv ushr 8).toByte(), bv.toByte()))
                    }
                    r.add(b!!)
                }
            }
        } catch (_: Exception) {}
        try { r.add(InetAddress.getByName("255.255.255.255")) } catch (_: Exception) {}
        return r
    }

    private fun startAnnounce() {
        announcing = true
        annThread = Thread {
            var sock: DatagramSocket? = null
            try {
                sock = DatagramSocket().apply { broadcast = true }
                while (announcing) {
                    val o = try { JSONObject(info) } catch (_: Exception) { JSONObject() }
                    o.put("cb", 1); o.put("port", PORT)
                    val data = o.toString().toByteArray()
                    for (a in broadcastAddrs()) try { sock.send(DatagramPacket(data, data.size, a, DISC_PORT)) } catch (_: Exception) {}
                    Thread.sleep(1500)
                }
            } catch (_: Exception) {} finally { try { sock?.close() } catch (_: Exception) {} }
        }.also { it.isDaemon = true; it.start() }
    }

    // ---------------- AXTARIŞ ----------------
    @JavascriptInterface fun scanStart() {
        if (scanning) return
        scanning = true
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            mlock = wm.createMulticastLock("cb-lan").also { it.setReferenceCounted(false); it.acquire() }
        } catch (_: Exception) {}
        scanThread = Thread {
            var s: DatagramSocket? = null
            try {
                s = DatagramSocket(null).apply { reuseAddress = true; broadcast = true; bind(InetSocketAddress(DISC_PORT)) }
                scanSock = s
                val buf = ByteArray(2048)
                while (scanning) {
                    val p = DatagramPacket(buf, buf.size); s.receive(p)
                    try {
                        val o = JSONObject(String(p.data, 0, p.length))
                        if (o.optInt("cb") != 1) continue
                        o.put("ip", p.address.hostAddress)
                        js("window.CBLan&&CBLan.found($o)")
                    } catch (_: Exception) {}
                }
            } catch (_: Exception) {} finally { try { s?.close() } catch (_: Exception) {} }
        }.also { it.isDaemon = true; it.start() }
    }
    @JavascriptInterface fun scanStop() {
        scanning = false
        try { scanSock?.close() } catch (_: Exception) {}; scanSock = null
        try { mlock?.release() } catch (_: Exception) {}; mlock = null
    }

    fun shutdown() { scanStop(); hostStop() }
}
