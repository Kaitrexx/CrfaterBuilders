package com.crafterbuilders.game;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * LAN körpüsü: JavaScript-də window.CBLan kimi görünür.
 * Host: UDP yayım (47777) + TCP server (47778). Qonaq: UDP dinləyir, siyahı yaradır, TCP ilə offer/answer kodlarını mübadilə edir.
 * Oyunun özü (WebRTC) bağlantını sonra birbaşa qurur.
 */
public class LanBridge {

    static final int UDP_PORT = 47777;
    static final int TCP_PORT = 47778;

    private static class Entry {
        String ip; int port; String world; String host; long last;
    }

    private final Context ctx;
    private final WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private WifiManager.MulticastLock mlock;

    // ---- scan ----
    private final Map<String, Entry> found = new ConcurrentHashMap<>();
    private volatile boolean scanning = false;
    private volatile int scanGen = 0;
    private DatagramSocket scanSock;

    // ---- host ----
    private volatile boolean hosting = false;
    private volatile int hostGen = 0;
    private volatile String hostWorld = "World";
    private volatile String hostName = "";
    private ServerSocket server;
    private DatagramSocket beacon;
    private final AtomicInteger nextId = new AtomicInteger(0);
    private final Map<Integer, ArrayBlockingQueue<String>> replies = new ConcurrentHashMap<>();

    // ---- client ----
    private Socket cliSock;
    private BufferedReader cliIn;
    private Writer cliOut;

    public LanBridge(Context ctx, WebView web) {
        this.ctx = ctx.getApplicationContext();
        this.web = web;
    }

    // ================= JS helpers =================

    private void js(final String code) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                try {
                    web.evaluateJavascript(code, null);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private static String q(String s) {
        return JSONObject.quote(s == null ? "" : s);
    }

    // ================= network helpers =================

    private static Set<String> localIps() {
        Set<String> out = new HashSet<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    out.add(a.getHostAddress());
                }
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private static List<InetAddress> broadcastTargets() {
        List<InetAddress> out = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress b = ia.getBroadcast();
                    if (b != null) out.add(b);
                }
            }
        } catch (Exception ignored) {
        }
        try {
            out.add(InetAddress.getByName("255.255.255.255"));
        } catch (Exception ignored) {
        }
        return out;
    }

    private void lockOn() {
        try {
            if (mlock == null) {
                WifiManager wm = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    mlock = wm.createMulticastLock("cblan");
                    mlock.setReferenceCounted(false);
                }
            }
            if (mlock != null && !mlock.isHeld()) mlock.acquire();
        } catch (Exception ignored) {
        }
    }

    private void lockOff() {
        try {
            if (mlock != null && mlock.isHeld() && !scanning && !hosting) mlock.release();
        } catch (Exception ignored) {
        }
    }

    // ================= scan (qonaq tərəfi) =================

    @JavascriptInterface
    public synchronized void startScan() {
        if (scanning) return;
        scanning = true;
        final int gen = ++scanGen;
        lockOn();
        new Thread(new Runnable() {
            @Override
            public void run() {
                DatagramSocket s = null;
                try {
                    s = new DatagramSocket(null);
                    s.setReuseAddress(true);
                    s.bind(new InetSocketAddress(UDP_PORT));
                    s.setBroadcast(true);
                    s.setSoTimeout(1000);
                    scanSock = s;
                    byte[] buf = new byte[1024];
                    while (scanning && gen == scanGen) {
                        try {
                            DatagramPacket p = new DatagramPacket(buf, buf.length);
                            s.receive(p);
                            String ip = p.getAddress().getHostAddress();
                            if (localIps().contains(ip)) continue;
                            JSONObject o = new JSONObject(new String(p.getData(), 0, p.getLength(), "UTF-8"));
                            if (o.optInt("v", 0) != 1) continue;
                            Entry e = new Entry();
                            e.ip = ip;
                            e.port = o.optInt("p", TCP_PORT);
                            e.world = o.optString("w", "World");
                            e.host = o.optString("h", "");
                            e.last = System.currentTimeMillis();
                            found.put(ip + ":" + e.port, e);
                        } catch (SocketTimeoutException ignored) {
                        } catch (Exception ex) {
                            if (!scanning || gen != scanGen) break;
                        }
                    }
                } catch (Exception ignored) {
                } finally {
                    try {
                        if (s != null) s.close();
                    } catch (Exception ignored) {
                    }
                }
            }
        }, "cblan-scan").start();
    }

    @JavascriptInterface
    public synchronized void stopScan() {
        scanning = false;
        scanGen++;
        found.clear();
        try {
            if (scanSock != null) scanSock.close();
        } catch (Exception ignored) {
        }
        lockOff();
    }

    @JavascriptInterface
    public String worlds() {
        long now = System.currentTimeMillis();
        JSONArray arr = new JSONArray();
        Iterator<Map.Entry<String, Entry>> it = found.entrySet().iterator();
        while (it.hasNext()) {
            Entry e = it.next().getValue();
            if (now - e.last > 6000) {
                it.remove();
                continue;
            }
            try {
                JSONObject o = new JSONObject();
                o.put("ip", e.ip);
                o.put("port", e.port);
                o.put("w", e.world);
                o.put("h", e.host);
                arr.put(o);
            } catch (Exception ignored) {
            }
        }
        return arr.toString();
    }

    // ================= host =================

    @JavascriptInterface
    public synchronized void startHost(String world, String host) {
        hostWorld = clip(world, 40);
        hostName = clip(host, 24);
        if (hosting) return;
        hosting = true;
        final int gen = ++hostGen;
        lockOn();

        // TCP server
        new Thread(new Runnable() {
            @Override
            public void run() {
                ServerSocket ss = null;
                try {
                    ss = new ServerSocket();
                    ss.setReuseAddress(true);
                    ss.bind(new InetSocketAddress(TCP_PORT));
                    ss.setSoTimeout(1000);
                    server = ss;
                    while (hosting && gen == hostGen) {
                        try {
                            final Socket c = ss.accept();
                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    handleClient(c);
                                }
                            }, "cblan-client").start();
                        } catch (SocketTimeoutException ignored) {
                        } catch (Exception ex) {
                            if (!hosting || gen != hostGen) break;
                        }
                    }
                } catch (Exception ignored) {
                } finally {
                    try {
                        if (ss != null) ss.close();
                    } catch (Exception ignored) {
                    }
                }
            }
        }, "cblan-server").start();

        // UDP beacon
        new Thread(new Runnable() {
            @Override
            public void run() {
                DatagramSocket bs = null;
                try {
                    bs = new DatagramSocket();
                    bs.setBroadcast(true);
                    beacon = bs;
                    while (hosting && gen == hostGen) {
                        try {
                            JSONObject o = new JSONObject();
                            o.put("v", 1);
                            o.put("w", hostWorld);
                            o.put("h", hostName);
                            o.put("p", TCP_PORT);
                            byte[] data = o.toString().getBytes("UTF-8");
                            for (InetAddress target : broadcastTargets()) {
                                try {
                                    bs.send(new DatagramPacket(data, data.length, target, UDP_PORT));
                                } catch (Exception ignored) {
                                }
                            }
                        } catch (Exception ignored) {
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException ie) {
                            break;
                        }
                    }
                } catch (Exception ignored) {
                } finally {
                    try {
                        if (bs != null) bs.close();
                    } catch (Exception ignored) {
                    }
                }
            }
        }, "cblan-beacon").start();
    }

    @JavascriptInterface
    public synchronized void stopHost() {
        hosting = false;
        hostGen++;
        try {
            if (server != null) server.close();
        } catch (Exception ignored) {
        }
        try {
            if (beacon != null) beacon.close();
        } catch (Exception ignored) {
        }
        lockOff();
    }

    /** JS host: onJoinReq(id) üçün cavab (offer kodu). Boş sətir = rədd. */
    @JavascriptInterface
    public void reply(int id, String offer) {
        ArrayBlockingQueue<String> qu = replies.get(id);
        if (qu != null) qu.offer(offer == null ? "" : offer.replace("\n", "").replace("\r", "").trim());
    }

    private void handleClient(Socket s) {
        int id = nextId.incrementAndGet();
        ArrayBlockingQueue<String> qu = new ArrayBlockingQueue<>(1);
        replies.put(id, qu);
        boolean asked = false;
        try {
            s.setSoTimeout(8000);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
            Writer out = new OutputStreamWriter(s.getOutputStream(), "UTF-8");
            String line = in.readLine();
            if (line == null || !line.startsWith("JOIN")) return;

            asked = true;
            js("window.__cbLan && window.__cbLan.onJoinReq(" + id + ")");
            String offer = qu.poll(15, TimeUnit.SECONDS);
            if (offer == null || offer.isEmpty()) {
                out.write("NO\n");
                out.flush();
                js("window.__cbLan && window.__cbLan.onHostFail(" + id + ")");
                return;
            }
            out.write(offer + "\n");
            out.flush();

            s.setSoTimeout(30000);
            String answer = in.readLine();
            if (answer == null || answer.isEmpty()) {
                js("window.__cbLan && window.__cbLan.onHostFail(" + id + ")");
                return;
            }
            js("window.__cbLan && window.__cbLan.onAnswer(" + id + "," + q(answer.trim()) + ")");
            out.write("OK\n");
            out.flush();
        } catch (Exception e) {
            if (asked) js("window.__cbLan && window.__cbLan.onHostFail(" + id + ")");
        } finally {
            replies.remove(id);
            try {
                s.close();
            } catch (Exception ignored) {
            }
        }
    }

    // ================= client (qonaq qoşulur) =================

    @JavascriptInterface
    public void connect(final String ip, final int port) {
        closeClient();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Socket s = null;
                try {
                    s = new Socket();
                    s.connect(new InetSocketAddress(ip, port), 5000);
                    s.setSoTimeout(20000);
                    BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
                    Writer out = new OutputStreamWriter(s.getOutputStream(), "UTF-8");
                    out.write("JOIN\n");
                    out.flush();
                    String offer = in.readLine();
                    if (offer == null || offer.isEmpty() || offer.equals("NO")) {
                        try {
                            s.close();
                        } catch (Exception ignored) {
                        }
                        js("window.__cbLan && window.__cbLan.onFail(" + q("host") + ")");
                        return;
                    }
                    synchronized (LanBridge.this) {
                        cliSock = s;
                        cliIn = in;
                        cliOut = out;
                    }
                    js("window.__cbLan && window.__cbLan.onOffer(" + q(offer.trim()) + ")");
                } catch (Exception e) {
                    try {
                        if (s != null) s.close();
                    } catch (Exception ignored) {
                    }
                    String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                    js("window.__cbLan && window.__cbLan.onFail(" + q(m) + ")");
                }
            }
        }, "cblan-connect").start();
    }

    @JavascriptInterface
    public void sendAnswer(final String answer) {
        final Socket s;
        final BufferedReader in;
        final Writer out;
        synchronized (this) {
            s = cliSock;
            in = cliIn;
            out = cliOut;
        }
        if (s == null || out == null) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    out.write(answer.replace("\n", "").replace("\r", "").trim() + "\n");
                    out.flush();
                    s.setSoTimeout(8000);
                    in.readLine();   // host "OK" göndərir
                } catch (Exception ignored) {
                } finally {
                    closeClient();
                }
            }
        }, "cblan-answer").start();
    }

    @JavascriptInterface
    public void abort() {
        closeClient();
    }

    private synchronized void closeClient() {
        try {
            if (cliSock != null) cliSock.close();
        } catch (Exception ignored) {
        }
        cliSock = null;
        cliIn = null;
        cliOut = null;
    }

    private static String clip(String s, int n) {
        if (s == null) return "";
        s = s.replace("\n", " ").trim();
        return s.length() > n ? s.substring(0, n) : s;
    }

    public void shutdown() {
        stopScan();
        stopHost();
        closeClient();
    }
}
